<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('impact_values', function (Blueprint $table) {
            $table->id();
            $table->foreignId('impact_indicator_id')->constrained()->cascadeOnDelete();
            $table->decimal('valeur', 14, 2);
            $table->string('periode')->nullable();
            // Pas de foreign key/enum cast ici volontairement : valeurs attendues
            // 'ziguinchor'|'sedhiou'|'kolda' (mêmes que App\Enums\Region), validées
            // au niveau du contrôleur — stockage en simple chaîne pour ne dépendre
            // d'aucun enum externe.
            $table->string('region')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('impact_values');
    }
};
