# Ajouter la photo d'un membre après coup

Ce fichier remplace `app/Http/Controllers/Api/Admin/MembershipController.php` dans ton projet. Il ajoute une nouvelle action `updatePhoto()` qui permet d'ajouter ou remplacer la photo d'un membre déjà existant — exactement ce qu'il te faut pour compléter les 171 membres importés depuis le fichier Excel, qui ont été créés sans photo (le fichier source ne contenait que des liens Google Drive, pas les images elles-mêmes).

## Installation

1. Remplace `app/Http/Controllers/Api/Admin/MembershipController.php` par celui de ce zip.

2. Ajoute cette route dans `routes/api.php`, dans le même groupe que les autres routes admin `memberships` :
   ```php
   Route::post('memberships/{membership}/photo', [MembershipController::class, 'updatePhoto']);
   ```

C'est tout — pas de migration, pas de nouvelle dépendance.

## Utilisation

Côté panneau admin (déjà installé côté front) :

1. Ouvre la fiche d'un membre (page Adhésions → clique sur son nom).
2. Sur sa photo, en haut à droite, une petite icône appareil photo — clique dessus (ou sur le lien "Ajouter une photo" qui apparaît sous la photo quand il n'y en a pas encore).
3. Choisis le fichier image, clique "Enregistrer". La photo est aussitôt visible sur la fiche et sur la carte de membre.

Fonctionne aussi pour remplacer une photo déjà existante (pas seulement pour en ajouter une la première fois). L'ancienne photo est automatiquement supprimée du serveur quand tu en mets une nouvelle, pour ne pas accumuler de fichiers inutiles.

Comme il n'y a pas encore d'outil pour faire ça en masse (une photo à la fois), il faudra répéter l'opération pour chacun des 171 membres si tu veux tous les compléter — dis-moi si tu préfères un moyen plus rapide (par exemple, associer des photos à partir d'un dossier nommé par ID de membre) et je peux construire ça à la place.
