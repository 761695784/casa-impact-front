# Indicateurs d'Impact — installation

Rend fonctionnelle la section admin **Indicateurs & Tableau de bord
d'Impact** (déjà présente côté frontend mais sans backend) et connecte la
page publique **/impact** aux vraies données — jusqu'ici elle affichait des
chiffres par défaut codés en dur (300, 130, 3, 6, 24, 18) car
`GET /api/public/impact-indicators` n'existait pas encore.

## Le principe

Un **indicateur** (ex. "Jeunes formés au leadership") a un libellé, une
unité et une description. Chaque indicateur peut avoir plusieurs **points de
mesure** (ex. "2025/2026, région Kolda, valeur 42") avec une période et/ou
une région optionnelles — c'est la somme de ces points qui donne le chiffre
affiché sur le site public. Tout est géré manuellement depuis l'admin (pas
de calcul automatique à partir d'autres données) ; il n'y a pas de notion de
brouillon — un indicateur créé est immédiatement visible sur le site public.

## 1. Copier les fichiers

- `database/migrations/2026_09_11_000001_create_impact_indicators_table.php` *(nouveau)*
- `database/migrations/2026_09_11_000002_create_impact_values_table.php` *(nouveau)*
- `app/Models/ImpactIndicator.php` *(nouveau)*
- `app/Models/ImpactValue.php` *(nouveau)*
- `app/Http/Resources/ImpactIndicatorResource.php` *(nouveau)*
- `app/Http/Resources/ImpactValueResource.php` *(nouveau)*
- `app/Http/Controllers/Api/Admin/ImpactIndicatorController.php` *(nouveau)*
- `app/Http/Controllers/Api/Admin/ImpactValueController.php` *(nouveau)*
- `app/Http/Controllers/Api/Public/ImpactIndicatorController.php` *(nouveau)*

## 2. Lancer la migration

```bash
php artisan migrate
```

Crée 2 nouvelles tables : `impact_indicators` et `impact_values`. Aucune
table existante n'est modifiée.

## 3. Ajouter les routes

Dans `routes/api.php` :

- dans le groupe **admin protégé** :

  ```php
  use App\Http\Controllers\Api\Admin\ImpactIndicatorController;
  use App\Http\Controllers\Api\Admin\ImpactValueController;

  Route::get('impact-indicators', [ImpactIndicatorController::class, 'index']);
  Route::post('impact-indicators', [ImpactIndicatorController::class, 'store']);
  Route::get('impact-indicators/{impactIndicator}', [ImpactIndicatorController::class, 'show']);
  Route::put('impact-indicators/{impactIndicator}', [ImpactIndicatorController::class, 'update']);
  Route::delete('impact-indicators/{impactIndicator}', [ImpactIndicatorController::class, 'destroy']);
  Route::post('impact-indicators/{impactIndicator}/values', [ImpactIndicatorController::class, 'addValue']);
  Route::put('impact-values/{impactValue}', [ImpactValueController::class, 'update']);
  Route::delete('impact-values/{impactValue}', [ImpactValueController::class, 'destroy']);
  ```

- dans le groupe **public** :

  ```php
  use App\Http\Controllers\Api\Public\ImpactIndicatorController as PublicImpactIndicatorController;

  Route::get('impact-indicators', [PublicImpactIndicatorController::class, 'index']);
  ```

  (Alias `as PublicImpactIndicatorController` pour éviter un conflit avec
  l'import du contrôleur admin homonyme, si les deux `use` se retrouvent
  dans le même fichier — même pattern que `Api\Admin\MembershipController` /
  `Api\Public\MembershipController` déjà dans votre projet.)

## Comportement

- **Accès** : les routes `admin/impact-indicators*` sont protégées
  uniquement par le middleware du groupe (`auth:sanctum`), sans permission
  plus fine — accessibles à tous les rôles admin, comme convenu le
  2026-09-11 (la Cartographie et l'Impact restent hors du système de
  permissions par rôle pour l'instant).
- **Validation** : `libelle` requis (min. 3 caractères), `unite` et
  `description` optionnels pour un indicateur ; `valeur` requise (numérique),
  `periode` et `region` (`ziguinchor`/`sedhiou`/`kolda`) optionnels pour un
  point de mesure.
- **Suppression en cascade** : supprimer un indicateur supprime tous ses
  points de mesure (`cascadeOnDelete` sur la migration).
- **Page publique /impact** : une fois ce module installé et au moins un
  indicateur créé, les vrais chiffres remplaceront automatiquement les
  valeurs par défaut (300, 130, etc.) affichées jusqu'ici sur
  `ImpactOverviewStats`/`ImpactIndicators` — aucune modification frontend
  n'est nécessaire, ces composants sont déjà branchés sur l'API réelle.

## Réponse d'un indicateur

```json
{
  "id": 1,
  "libelle": "Jeunes formés au leadership",
  "unite": "bénéficiaires",
  "description": "...",
  "values": [
    { "id": 1, "valeur": 42, "periode": "2025/2026", "region": "kolda" }
  ],
  "created_at": "...",
  "updated_at": "..."
}
```
