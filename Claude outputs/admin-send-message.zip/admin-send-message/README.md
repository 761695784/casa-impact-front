# Envoyer un message (admin) — installation

Nouvelle fonctionnalité : un bouton **"Envoyer un message"** dans la partie admin
(section Messages) ouvre une modal permettant de composer un email libre
(sujet + texte) et de l'envoyer à un ou plusieurs destinataires (membres
choisis dans une liste et/ou adresses email tapées librement), au **format
email officiel Casa Impact** (logo, filigrane, couleurs, signature) — en
réutilisant le même layout `emails.layout` que les emails d'adhésion
(`received.blade.php` / `validated.blade.php`).

Aucun message n'est enregistré en base : c'est un envoi direct, indépendant
des `ContactMessage` (messages de contact reçus depuis le site public).

## 1. Copier les fichiers

Copiez ces 3 fichiers dans votre projet, aux mêmes emplacements :

- `app/Mail/AdminBroadcastMessage.php` *(nouveau)*
- `resources/views/emails/admin-message.blade.php` *(nouveau)*
- `app/Http/Controllers/Api/Admin/AdminMessageController.php` *(nouveau)*

## 2. Ajouter la route

Dans `routes/api.php`, à l'intérieur du **même groupe protégé** que vos
autres routes admin (celui qui contient déjà `memberships`,
`contact-messages`, etc. — normalement sous un middleware du type
`auth:sanctum` + vérification admin), ajoutez :

```php
use App\Http\Controllers\Api\Admin\AdminMessageController;

// ...

Route::post('messages/send', [AdminMessageController::class, 'send']);
```

Cela crée l'endpoint `POST /api/admin/messages/send`, attendu par le
frontend. Comme il n'y a pas de modèle associé (ce n'est pas une ressource
`ContactMessage`), aucune autre route n'est nécessaire.

**Important** : ce contrôleur ne fait volontairement **aucun appel à
`$this->authorize()`** — il compte uniquement sur le middleware du groupe de
routes pour protéger l'accès (comme si c'était n'importe quelle autre route
`admin/*`). Si votre projet utilise des permissions plus fines (ex. certains
admins n'ont pas le droit d'envoyer d'email), ajoutez la vérification qui
convient en première ligne de `send()`.

## 3. Vérifier la config mail

Cette fonctionnalité utilise `Mail::to($email)->send(...)`, exactement comme
les emails `MembershipReceived` / `MembershipValidated` déjà en place —
aucune configuration supplémentaire n'est nécessaire si ceux-ci fonctionnent
déjà.

## Comportement

- **Validation** : `subject` (requis, 255 caractères max), `message` (requis,
  10 000 caractères max), `recipients` (tableau requis d'au moins 1 email
  valide, 200 max).
- **Envoi** : un email est envoyé individuellement à chaque destinataire
  (boucle `Mail::to()->send()`, pas de "cc" groupé — chacun ne voit que sa
  propre adresse). Si l'envoi échoue pour une adresse en particulier
  (adresse invalide côté serveur mail, timeout, etc.), les autres continuent
  d'être envoyés normalement ; la réponse liste les échecs dans `failed`.
- **Mise en forme** : la modal propose une petite barre d'outils (Gras,
  Italique, Souligné, Liste à puces, Lien) au-dessus du champ message —
  cliquer sur un bouton insère une mini-syntaxe dans le texte : `**gras**`,
  `*italique*`, `__souligné__`, `- élément de liste`, `[texte](https://...)`.
  Le texte saisi reste du texte brut à tout moment (jamais du HTML) ; c'est
  `AdminMessageController::renderMessageHtml()` qui convertit cette
  mini-syntaxe en HTML au moment de l'envoi.
- **Sécurité du contenu** : chaque fragment de texte est toujours échappé
  (`e()`) avant que le contrôleur y insère ses propres balises autour — le
  HTML final n'est donc jamais construit à partir de HTML fourni par
  l'utilisateur, même en cas d'appel direct à l'API (en dehors de la
  modal) avec du texte contenant p. ex. `<script>`. Les paragraphes
  (séparés par une ligne vide) deviennent des `<p>`, les lignes commençant
  par `- ` deviennent une liste `<ul>`, dans le même style visuel que les
  autres emails Casa Impact.
- **Sujet en gras dans le corps du message** : en plus de servir d'objet
  d'email (visible dans la boîte de réception), le sujet est maintenant
  aussi affiché en haut du corps du message, en gras, dans une police serif
  élégante (Georgia — police système fiable, contrairement à une police
  Google Fonts qui ne se charge pas dans la plupart des clients mail comme
  Outlook desktop).
- **Pas de file d'attente (queue)** : l'envoi est synchrone, comme le reste
  de l'application actuellement. Pour un grand nombre de destinataires (au
  -delà d'une trentaine environ), l'admin peut voir un temps de chargement
  un peu plus long le temps que tous les emails partent. Si cela devient
  gênant à l'usage, on pourra faire passer `AdminBroadcastMessage` par
  `ShouldQueue` plus tard — non fait ici pour rester cohérent avec le reste
  du projet, qui n'utilise pas de queue à ce jour.

## Réponse de l'endpoint

```json
{
  "message": "Message envoyé avec succès à 3 destinataire(s).",
  "sent": 3,
  "failed": []
}
```
