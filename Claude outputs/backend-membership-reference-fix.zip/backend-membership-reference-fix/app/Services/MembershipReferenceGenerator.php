<?php

namespace App\Services;

use App\Models\Membership;
use App\Models\MembershipReferenceCounter;
use Illuminate\Support\Facades\DB;

/**
 * Format aligné sur la numérotation OFFICIELLE historique (fichier Excel
 * pré-site) : CI-{année}-{séquence sur 4 chiffres}, ex. CI-2026-0001 —
 * corrigé le 2026-09-14 (accord explicite). La version précédente
 * produisait un format à 6 chiffres (CI-2026-000001) pour tout nouveau
 * membre créé depuis le site/l'admin, délibérément différent des ID
 * historiques (4 chiffres) pour garantir qu'ils ne puissent jamais entrer
 * en collision — mais ça donnait deux styles de numéro incohérents selon
 * l'origine du membre. Les deux formats utilisent désormais la même
 * séquence par année (voir syncFromExisting() ci-dessous pour la garantie
 * anti-collision, assurée autrement).
 *
 * Réplique par ailleurs le mécanisme de App\Services\ApplicationReferenceGenerator
 * (même garantie d'atomicité via lockForUpdate), sur sa propre table de
 * compteur (`membership_reference_counters`) — compteur indépendant de
 * celui des candidatures.
 */
class MembershipReferenceGenerator
{
    public function generate(): string
    {
        $annee = (int) date('Y');

        $sequence = DB::transaction(function () use ($annee) {
            $counter = MembershipReferenceCounter::query()
                ->where('annee', $annee)
                ->lockForUpdate()
                ->first();

            if (! $counter) {
                // Double SELECT volontaire : protège contre le cas limite
                // d'un changement d'année pile au moment d'une soumission
                // concurrente (voir ApplicationReferenceGenerator).
                $counter = MembershipReferenceCounter::create(['annee' => $annee, 'sequence' => 0]);
                $counter = MembershipReferenceCounter::query()->where('annee', $annee)->lockForUpdate()->first();
            }

            $counter->increment('sequence');

            return $counter->sequence;
        });

        return sprintf('CI-%d-%04d', $annee, $sequence);
    }

    /**
     * Recale le compteur de CHAQUE année sur le plus grand numéro de membre
     * réellement présent en base au format CI-{année}-{séquence} — ne fait
     * jamais reculer un compteur, seulement avancer. Deux usages :
     *
     *   1. Appelée automatiquement à la fin de LegacyMembershipImporter::commit()
     *      après chaque import historique, pour que le PROCHAIN membre créé
     *      manuellement ou via le site continue bien après le dernier
     *      numéro importé (jamais de collision, jamais de "retour à 1").
     *   2. Exposée en Artisan (`php artisan membership:sync-reference-counter`)
     *      pour rattraper un compteur resté désynchronisé — notamment celui
     *      d'un import déjà fait AVANT ce correctif (l'ancien commit() ne
     *      touchait pas du tout au compteur).
     *
     * Idempotente : peut être appelée autant de fois que nécessaire sans
     * effet de bord.
     *
     * @return array<int,array{annee:int, avant:int, apres:int}> le détail par année (avant/après ce recalage)
     */
    public function syncFromExisting(): array
    {
        $maxByYear = [];

        Membership::query()
            ->whereNotNull('numero_membre')
            ->pluck('numero_membre')
            ->each(function (string $numero) use (&$maxByYear) {
                if (preg_match('/^CI-(\d{4})-(\d+)$/', $numero, $matches)) {
                    $annee = (int) $matches[1];
                    $seq = (int) $matches[2];

                    if (! isset($maxByYear[$annee]) || $seq > $maxByYear[$annee]) {
                        $maxByYear[$annee] = $seq;
                    }
                }
            });

        $changes = [];

        foreach ($maxByYear as $annee => $maxSeq) {
            DB::transaction(function () use ($annee, $maxSeq, &$changes) {
                $counter = MembershipReferenceCounter::query()->where('annee', $annee)->lockForUpdate()->first();
                $avant = $counter->sequence ?? 0;
                $apres = max($avant, $maxSeq);

                if (! $counter) {
                    MembershipReferenceCounter::create(['annee' => $annee, 'sequence' => $apres]);
                } elseif ($apres > $counter->sequence) {
                    $counter->update(['sequence' => $apres]);
                }

                $changes[] = ['annee' => $annee, 'avant' => $avant, 'apres' => $apres];
            });
        }

        return $changes;
    }
}
