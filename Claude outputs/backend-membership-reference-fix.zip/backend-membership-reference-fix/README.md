# Numéros d'adhésion — format aligné + compteur qui suit l'import

Corrige deux choses liées au numéro de membre (`numero_membre`, ex.
`CI-2026-0001`) :

1. **Format incohérent** : les membres importés depuis ta base officielle
   (Excel) ont un numéro à 4 chiffres (`CI-2026-0001`), alors que tout
   nouveau membre créé depuis le site ou l'admin recevait jusqu'ici un
   numéro à **6 chiffres** (`CI-2026-000012`) — volontairement différent à
   l'origine pour éviter toute collision entre les deux. Corrigé : les deux
   utilisent maintenant le **même format à 4 chiffres**.
2. **Compteur qui ne suivait pas l'import** : après un import Excel, le
   compteur qui sert à générer le numéro du prochain membre n'était jamais
   mis à jour — il restait bloqué à sa dernière valeur de test. Corrigé : il
   se recale maintenant automatiquement sur le plus grand numéro réellement
   en base, à la fin de **chaque** import (bouton admin ou commande Artisan).

## 1. Copier les fichiers

Remplace entièrement ces 3 fichiers existants par ceux de ce zip :

- `app/Services/MembershipReferenceGenerator.php`
- `app/Services/LegacyMembershipImporter.php`
- `app/Console/Commands/ImportLegacyMemberships.php` *(juste un commentaire mis à jour, aucun changement de comportement)*

Et ajoute ce nouveau fichier :

- `app/Console/Commands/SyncMembershipReferenceCounter.php` *(nouveau)*

Aucune route, aucune migration à ajouter.

## 2. Rattraper le compteur MAINTENANT (à faire une seule fois)

Comme tu as déjà importé ta base officielle **avant** ce correctif, ton
compteur actuel est resté bloqué à sa valeur de test (12, d'après la carte
d'Anna Maronne : `CI-2026-000012`) — il n'a jamais tenu compte des ~171
membres importés. Après avoir copié les fichiers ci-dessus, lance une fois :

```bash
php artisan membership:sync-reference-counter
```

Ça affiche, pour chaque année trouvée en base, l'ancien et le nouveau
compteur (ex. `Année 2026 : compteur 12 -> 171.`). Sans effet si tu le
relances par erreur — aucun risque.

**Après ça**, tout nouveau membre (manuel ou depuis le site) recevra un
numéro qui continue bien après le dernier importé (`CI-2026-0172`,
`CI-2026-0173`, ...), au même format à 4 chiffres que tes numéros officiels.

## Pour les prochains imports

Rien à faire de spécial : `LegacyMembershipImporter::commit()` (utilisé à la
fois par le bouton admin "Importer l'historique (Excel)" et par
`php artisan membership:import-legacy --commit`) recale maintenant le
compteur automatiquement à chaque import, même si l'import ne crée aucun
nouveau membre (fichier déjà importé rejoué par erreur, par exemple) — donc
plus jamais besoin de relancer `membership:sync-reference-counter` à la
main après un import fait avec cette version.

## Détail technique

`MembershipReferenceGenerator::syncFromExisting()` scanne tous les
`numero_membre` en base au format `CI-{année}-{séquence}`, calcule le plus
grand numéro par année, et relève (jamais ne baisse) le compteur de chaque
année en conséquence. Le format généré passe de `sprintf('CI-%d-%06d', ...)`
à `sprintf('CI-%d-%04d', ...)` — si un jour une année dépasse 9999 membres,
le numéro s'étend naturellement à 5 chiffres sans perte de données (juste
plus de zéro de tête).
