# Ajout manuel d'un membre — backend

Ces 2 fichiers remplacent leurs équivalents dans ton projet Laravel. Ils ajoutent la possibilité de préciser un `numero_membre` personnalisé lors de l'ajout manuel d'un membre depuis le panneau admin (le bouton "Ajouter un membre" côté front, déjà installé).

## Ce qui change

- `app/Http/Requests/Admin/StoreMembershipManualRequest.php` : accepte maintenant un champ optionnel `numero_membre` (lettres/chiffres/tirets, unique en base).
- `app/Http/Controllers/Api/Admin/MembershipController.php` : dans `store()`, si `numero_membre` est fourni, il est conservé tel quel ; sinon un nouvel ID est généré automatiquement comme avant. `send_welcome_email` passe aussi à `false` par défaut (au lieu de `true`) — cohérent avec le fait que cet endpoint sert avant tout à ajouter des membres historiques, qui n'ont pas à recevoir l'email "adhésion reçue aujourd'hui".

## Installation

Remplace simplement les 2 fichiers correspondants dans ton projet (mêmes chemins). Aucune migration, aucune nouvelle dépendance — juste ces 2 fichiers.

## Ce que ça permet côté panneau admin

Le bouton "Ajouter un membre" (en haut de la page Adhésions) ouvre un formulaire avec, tout en bas, une section "Membre historique" :

- Un champ **ID existant** (optionnel) — à remplir uniquement si ce membre a déjà une carte imprimée (ex. `CI-2026-0042`), pour la conserver telle quelle. Laissé vide, un nouvel ID est généré automatiquement.
- Une case **Envoyer l'email de bienvenue**, décochée par défaut.

Le membre est créé directement au statut "Validée" (comme pour toute saisie manuelle admin), avec la photo, la région, le domaine/type de contribution, etc.

Pour importer en une fois tout l'historique du fichier Excel, c'est la commande `membership:import-legacy` livrée séparément qu'il faut utiliser — ce formulaire-ci sert aux ajouts au coup par coup (un oubli, une correction, un nouveau cas particulier).
