# Rappel de paiement (admin) — installation

Nouvelle fonctionnalité : un bouton **"Envoyer un rappel de paiement"** sur
la page admin **Adhésions** envoie un email de rappel (mêmes instructions de
paiement Wave que l'email de confirmation initial) à **tous les membres dont
l'adhésion est encore `en_attente_paiement`** — c'est-à-dire ceux qui n'ont
pas encore finalisé leur adhésion.

## 1. Remplacer le contrôleur

Remplacez entièrement votre fichier existant par celui-ci (il contient tout
ce qui existait déjà + la nouvelle méthode `sendPaymentReminders`) :

- `app/Http/Controllers/Api/Admin/MembershipController.php` *(remplace l'existant)*

Et copiez ces 2 nouveaux fichiers :

- `app/Mail/MembershipPaymentReminder.php` *(nouveau)*
- `resources/views/emails/memberships/payment-reminder.blade.php` *(nouveau)*

## 2. Ajouter la route

Dans `routes/api.php`, dans le **même groupe** que vos routes
`memberships/...` existantes (juste à côté de la route `memberships/{membership}/photo`
ajoutée précédemment), ajoutez :

```php
Route::post('memberships/payment-reminder', [MembershipController::class, 'sendPaymentReminders']);
```

**Important** : placez cette route **avant** toute route du type
`memberships/{membership}` (si vous en avez une avec un paramètre générique
juste après `memberships/`), sinon Laravel risque d'interpréter
"payment-reminder" comme un `{membership}` et de renvoyer une 404/500. Vos
routes `memberships/import-legacy/...` et `memberships/{membership}/photo`
existantes suivent déjà cette règle, donc placez celle-ci au même endroit
dans le groupe (avant `memberships/{membership}` s'il y en a une, après les
routes plus spécifiques comme `import-legacy`).

## Comportement

- **Cible** : par défaut (aucun corps de requête, ou `membership_ids` vide),
  cible **tous** les membres avec `statut = en_attente_paiement` au moment
  de l'envoi — toujours à jour, pas besoin de rafraîchir une liste côté
  frontend avant d'envoyer.
- **Sécurité** : même si `membership_ids` est fourni (prévu pour un futur
  bouton "rappel" ligne par ligne, pas encore branché côté frontend), la
  requête ne peut jamais relancer un membre déjà `validee` ou `refusee` —
  le filtre `statut = en_attente_paiement` s'applique toujours en premier.
- **Contenu de l'email** : identique en substance à l'email de confirmation
  initial (`MembershipReceived`) — montant et numéro Wave, numéro WhatsApp
  pour l'envoi de la capture — seule l'introduction change ("nous n'avons
  pas encore reçu votre paiement" au lieu de "nous avons bien reçu votre
  demande"). Ces informations viennent de `config('casaimpact.*')`, exactement
  comme pour les autres emails d'adhésion : aucune nouvelle configuration
  n'est nécessaire si ceux-ci fonctionnent déjà.
- **Si aucun membre en attente** : répond `sent: 0` avec un message clair,
  sans erreur.
- **Échecs partiels** : comme pour "Envoyer un message", si l'envoi échoue
  pour un membre en particulier, les autres continuent normalement ; la
  réponse liste les numéros de membre en échec dans `failed`.

## Réponse de l'endpoint

```json
{
  "message": "Rappel envoyé avec succès à 42 membre(s).",
  "sent": 42,
  "failed": []
}
```
