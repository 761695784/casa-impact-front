# Cartographie Territoriale — installation

Corrige l'erreur **"Impossible de charger la cartographie"** (route
`api/admin/cartography` introuvable) sur la page admin **Cartographie**, et
connecte au passage la page publique **/carte** (`GET /api/public/map`).

## Le principe

Aucun de vos modèles existants (Programmes, Appels à candidatures, Talents)
n'a de latitude/longitude en base — seulement une `region`
(ziguinchor/kolda/sédhiou) et un texte libre de localisation (`localisation`
pour Programme/Talent, `lieu` pour Appel à candidatures). Plutôt que
d'ajouter des champs partout, cette fonctionnalité **déduit** la position de
chaque point à partir de ce texte, via une table de correspondance des
communes de Casamance (`CasamanceLocations`) — accord du 2026-09-11.

La carte affiche donc, sans aucune saisie supplémentaire :

- tous les **Programmes**, **Appels à candidatures** et **Talents** déjà en
  base (positionnés sur leur commune si reconnue, sinon sur le centre de
  leur région) ;
- 3 points fixes **"Antenne Casa Impact"** (Ziguinchor, Kolda, Sédhiou),
  codés en dur pour l'instant (accord du 2026-09-11 — gérables depuis
  l'admin plus tard si besoin, il suffira alors de remplacer
  `CartographyAggregator::implantations()` par une vraie requête).

## 1. Copier les fichiers

Copiez ces fichiers dans votre projet, aux mêmes emplacements (tous
nouveaux, aucun fichier existant n'est modifié) :

- `app/Services/Cartography/CasamanceLocations.php` *(nouveau)*
- `app/Services/Cartography/CartographyAggregator.php` *(nouveau)*
- `app/Http/Controllers/Api/Admin/CartographyController.php` *(nouveau)*
- `app/Http/Controllers/Api/Public/CartographyController.php` *(nouveau)*

## 2. Ajouter les routes

Dans `routes/api.php` :

- dans le groupe **admin protégé** (celui qui contient déjà `memberships`,
  `contact-messages`, `messages/send`...) :

  ```php
  use App\Http\Controllers\Api\Admin\CartographyController;

  Route::get('cartography', [CartographyController::class, 'index']);
  ```

- dans le groupe **public** (celui qui contient déjà `domains`, `programs`,
  `talents`, etc.) :

  ```php
  use App\Http\Controllers\Api\Public\CartographyController as PublicCartographyController;

  Route::get('map', [PublicCartographyController::class, 'index']);
  ```

  (Les deux classes s'appellent `CartographyController` mais vivent dans des
  namespaces différents — comme `Api\Admin\MembershipController` et
  `Api\Public\MembershipController` déjà dans votre projet — d'où l'alias
  `as PublicCartographyController` pour éviter un conflit d'import si les
  deux `use` se retrouvent dans le même fichier.)

Pas de migration, pas de nouveau modèle : tout se lit à la volée depuis vos
tables existantes.

## Important — noms de champs attendus

Ce module suppose que vos modèles `Program`, `ApplicationCall`, `Talent` ont
bien les relations Eloquent `domain()` (Program, Talent) et `program()`
(ApplicationCall), telles que documentées dans votre `content.service.ts`
frontend. Si vos vrais noms de relation diffèrent, ajustez
`CartographyAggregator::programs()`/`applicationCalls()`/`talents()` en
conséquence (quelques lignes à adapter, tout est centralisé dans ce seul
fichier).

## Affiner les coordonnées

Toutes les coordonnées connues sont centralisées dans
`CasamanceLocations::COMMUNES` — un simple tableau `'nom de commune' =>
['lat' => ..., 'lng' => ..., 'departement' => ...]`. Pour ajouter une
commune non reconnue (elle retombera sinon sur le centre de sa région),
ajoutez-y une ligne : aucune autre modification n'est nécessaire.

## Filtres disponibles (vue admin uniquement)

`GET /api/admin/cartography?search=...&type=program|application-call|talent|implantation&region=ziguinchor|kolda|sedhiou`
— mêmes paramètres que ceux déjà envoyés par `cartography.service.ts`.

## Réponse de l'endpoint

```json
{
  "data": [
    {
      "id": 1,
      "type": "program",
      "latitude": 12.5665,
      "longitude": -16.2733,
      "libelle": "...",
      "region": "ziguinchor",
      "statut": "publie",
      "titre": "...",
      "slug": "...",
      "departement": "Ziguinchor",
      "commune": "Ziguinchor",
      "description": "...",
      "domaine_nom": "..."
    }
  ]
}
```
