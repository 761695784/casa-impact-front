<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Aligne `application_calls` sur le formulaire admin déjà conçu côté
 * frontend (section "Informations Générales" : résumé accrocheur affiché
 * dans les cartes/aperçus) — même rôle que `programs.resume`.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('application_calls', function (Blueprint $table) {
            $table->string('resume')->nullable()->after('description');
        });
    }

    public function down(): void
    {
        Schema::table('application_calls', function (Blueprint $table) {
            $table->dropColumn('resume');
        });
    }
};
