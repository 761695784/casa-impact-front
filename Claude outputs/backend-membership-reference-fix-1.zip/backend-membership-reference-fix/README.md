# Numéro d'adhésion — génération dynamique (suit les suppressions)

Ce zip **remplace** le précédent correctif du même nom (format 4 chiffres) —
si tu l'avais déjà installé, ces fichiers le remplacent entièrement, pas
besoin de les cumuler.

## Le problème que ça corrige

Après le premier correctif, le format était bon (`CI-2026-0001`, 4
chiffres), mais le numéro venait toujours d'un compteur qui ne fait
qu'**augmenter**, même après une suppression. Concrètement : dernier membre
`CI-2026-0172`, tu le supprimes, tu en crées un nouveau → il recevait
`CI-2026-0173` au lieu de réutiliser `0172`, qui était pourtant libre.

## Le principe désormais

Le prochain numéro n'est plus lu depuis un compteur stocké : il est
**recalculé à chaque fois**, à partir du plus grand `numero_membre`
réellement présent en base pour l'année. Une suppression libère donc
naturellement son numéro pour le prochain membre créé — plus besoin de
"synchroniser" quoi que ce soit après un import ou une suppression, c'est
automatique et toujours à jour ("dynamique", comme demandé).

La table `membership_reference_counters` reste utilisée, mais uniquement
comme verrou technique (pour qu'une génération à la seconde près ne puisse
jamais attribuer deux fois le même numéro) — plus comme source du chiffre
lui-même.

## 1. Remplacer les fichiers

- `app/Services/MembershipReferenceGenerator.php` *(remplace l'existant — logique de génération revue)*
- `app/Services/LegacyMembershipImporter.php` *(remplace l'existant — retire l'appel de resynchronisation du précédent correctif, devenu inutile)*
- `app/Console/Commands/ImportLegacyMemberships.php` *(remplace l'existant — juste un commentaire mis à jour)*

## 2. Supprimer un fichier devenu inutile

Si tu avais installé le précédent correctif, **supprime** ce fichier de ton
projet (sinon il référence une méthode qui n'existe plus et provoquera une
erreur si jamais quelqu'un lance la commande) :

- `app/Console/Commands/SyncMembershipReferenceCounter.php` *(à supprimer)*

Rien d'autre à faire : pas de nouvelle route, pas de migration, et rien à
lancer manuellement cette fois — le système se corrige tout seul dès que
ces fichiers sont en place.

## Vérifier

Supprime ton dernier membre (`CI-2026-0172` par exemple), crée-en un
nouveau : il doit récupérer exactement le même numéro. Crée-en un deuxième
sans rien supprimer entre-temps : il doit prendre le suivant normalement
(`0173`), sans jamais réutiliser un numéro encore attribué à un membre
existant.
