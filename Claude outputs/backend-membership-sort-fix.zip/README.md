# Liste des adhésions — tri "plus récent au plus ancien" fiabilisé

## Ce que montraient tes captures d'écran

Le tri était déjà `orderByDesc('created_at')` côté serveur, mais tes deux
captures montrent : `CI-2026-0172` en premier (logique, c'est le plus
récent), puis directement `CI-2026-0125, 0126, 0127, 0128, 0129, 0131…`
jusqu'à `0144` — dans l'ordre **croissant**, pas décroissant.

## La cause

Tous ces membres importés depuis l'Excel affichent la date du **14
septembre 2026** (aujourd'hui) — c'est-à-dire qu'ils partagent
très probablement le même `created_at` à la seconde près (import en masse
fait aujourd'hui). Or `ORDER BY created_at DESC` seul ne garantit **aucun**
ordre entre des lignes strictement ex æquo sur `created_at` — MySQL renvoie
alors ces lignes dans l'ordre qui l'arrange (en pratique, souvent leur
ordre d'insertion physique, donc croissant), ce qui donnait cette
impression de tri "cassé" au milieu d'une liste par ailleurs correcte.

## Le correctif

Un simple départage ajouté après `created_at` : `->orderByDesc('id')`.
`id` est strictement croissant à l'insertion et ne peut jamais être ex
æquo — donc entre deux membres importés à la même seconde, celui inséré en
dernier (id le plus grand) apparaît maintenant en premier, de façon
stable et reproductible à chaque chargement de page.

Appliqué à `index()` (liste affichée dans le panneau admin) et à
`export()` (export CSV), pour que les deux restent cohérents.

## Installer

Remplace ce seul fichier :

- `app/Http/Controllers/Api/Admin/MembershipController.php`

Rien d'autre à faire : pas de migration, pas de route, pas de commande à
lancer.

## Vérifier

Recharge la page Adhésions du panneau admin : la liste doit maintenant
afficher `CI-2026-0172` en premier, puis les membres importés aujourd'hui
dans l'ordre `0144, 0143, 0142, 0141, 0140, …` (décroissant), au lieu de
`0125, 0126, 0127…` (croissant) comme sur tes captures.
