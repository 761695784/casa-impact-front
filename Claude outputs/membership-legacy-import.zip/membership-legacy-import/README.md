# Import des adhérents historiques (pré-site)

Deux façons d'importer, **une seule fois**, les adhérents qui ont rejoint Casa Impact avant la mise en ligne du formulaire du site (ceux qui ont déjà leur carte imprimée avec un ID au format `CI-2026-0001`) :

1. **Depuis le panneau admin** — bouton "Importer l'historique (Excel)" en haut de la page Adhésions (déjà installé côté front).
2. **Depuis le terminal** — commande `php artisan membership:import-legacy` (pour un import fait directement sur le serveur).

Les deux utilisent exactement la même logique (un seul service partagé), donc produisent le même résultat quel que soit le chemin choisi.

## Ce que ça fait

- Lit ton fichier Excel (`Adhésion à l'organisation Casa Impact — réponses.xlsx`, onglets `Form_Responses` + `Cartes`).
- Crée les adhérents en base **en gardant leur ID existant tel quel** (aucun risque de collision : le générateur du site produit des ID à 6 chiffres `CI-2026-000001`, les anciens sont à 4 chiffres `CI-2026-0001`).
- Les membres déjà payés/validés sont créés au statut `validee`, ceux inscrits mais pas encore payés au statut `en_attente_paiement`.
- **Aucun email n'est envoyé** pour ces membres importés.
- Aperçu d'abord (rien n'est écrit), confirmation ensuite — que ce soit via le bouton admin ou la commande.
- Rejouable sans danger : un membre déjà présent en base (même `numero_membre`) est automatiquement ignoré, jamais dupliqué.
- Les photos ne sont pas importées (le fichier ne contient que des liens Google Drive, pas les images elles-mêmes) — la carte s'affichera avec l'encadré photo vide pour ces membres-là ; tu pourras compléter une photo plus tard via la fiche adhésion si tu veux.
- Le fichier Excel envoyé via le bouton admin est stocké temporairement côté serveur (jamais dans un dossier public), supprimé automatiquement dès la confirmation ou l'annulation de l'import, et un nettoyage de sécurité supprime aussi tout fichier oublié de plus de 30 minutes.

## Installation (à faire une seule fois)

1. Copie les fichiers de ce dossier dans ton projet Laravel, en gardant la même arborescence :
   - `app/Services/LegacyMembershipImporter.php` (nouveau — logique partagée)
   - `app/Console/Commands/ImportLegacyMemberships.php` (remplace la version précédente si tu l'avais déjà installée)
   - `app/Http/Controllers/Api/Admin/MembershipImportController.php` (nouveau — pour le bouton admin)
   - `database/migrations/2026_09_11_000000_make_membership_photo_path_nullable.php`

2. Installe la librairie de lecture Excel (si ce n'est pas déjà fait) :
   ```
   composer require phpoffice/phpspreadsheet
   ```

3. Lance la migration (rend `photo_path` optionnel pour ces membres sans photo numérisée) :
   ```
   php artisan migrate
   ```

4. **Ajoute les 3 routes** dans `routes/api.php`, à l'intérieur du même groupe que les autres routes admin `memberships` (celui protégé par `auth:sanctum`, à côté de `Route::apiResource('memberships', MembershipController::class)` et de la route `.../card`) :
   ```php
   use App\Http\Controllers\Api\Admin\MembershipImportController;

   Route::post('memberships/import-legacy/preview', [MembershipImportController::class, 'preview']);
   Route::post('memberships/import-legacy/commit', [MembershipImportController::class, 'commit']);
   Route::delete('memberships/import-legacy/{token}', [MembershipImportController::class, 'cancel']);
   ```
   Pas de middleware de permission particulier à ajouter : comme pour `store()`, l'autorisation se fait à l'intérieur du contrôleur (`$this->authorize('create', Membership::class)`), donc il suffit qu'elles soient dans le groupe déjà authentifié.

## Utilisation depuis le panneau admin

1. Page Adhésions → bouton "Importer l'historique (Excel)".
2. Sélectionne le fichier Excel, clique "Analyser le fichier" — un résumé chiffré s'affiche (combien seront créés, combien déjà présents, avertissements éventuels). Rien n'est encore écrit en base.
3. Clique "Confirmer l'import" — les membres sont créés, le résultat final s'affiche (nombre importé, éventuelles lignes en échec).
4. Une fois l'import vérifié dans la liste des adhésions, **supprime le fichier Excel** de ton ordinateur — il n'est plus nécessaire et contient des données confidentielles.

## Utilisation depuis le terminal (alternative)

1. Place ton fichier Excel **quelque part hors du dépôt Git** (par exemple `storage/app/imports/adhesions.xlsx`).
2. Aperçu :
   ```
   php artisan membership:import-legacy storage/app/imports/adhesions.xlsx
   ```
3. Import réel :
   ```
   php artisan membership:import-legacy storage/app/imports/adhesions.xlsx --commit
   ```
4. Supprime ensuite le fichier Excel du serveur.

## Cas particuliers déjà gérés automatiquement

- Une personne qui avait rempli le formulaire deux fois pour le même ID → la bonne ligne est choisie automatiquement (celle dont le statut correspond à la colonne `Validation`, fiable à 100%, de l'onglet Cartes).
- Une ligne technique cassée (message d'erreur à la place du statut) → ignorée, le vrai statut est déduit de la colonne `Validation`.
- Domaine de contribution avec plusieurs choix cochés → le premier est conservé comme champ structuré, le détail complet est noté dans "Note admin" de la fiche.

## Ajout au coup par coup (en dehors de cet import)

Pour ajouter un membre historique isolé (un oubli, une correction), utilise plutôt le bouton "Ajouter un membre" (livré séparément) — il permet de préciser un ID existant pour un seul membre à la fois.
